# Strategic Product Placement Analysis

This repository contains the full structure for the group project: **Strategic Product Placement Analysis**.

## 📁 Folder Structure

1. **Assignments** – Contains Assignment 1, 2, and 3 PDFs/screenshots.
2. **Ideation Phase** – Ideation documents, brainstorming sheets, idea validation.
3. **Requirement Analysis** – Customer Journey Maps, requirement docs.
4. **Project Design Phase** – Wireframes and UI/UX designs.
5. **Project Planning Phase** – Timelines, team roles, Gantt charts.
6. **Project Executable Files**
   - Dataset – Original and cleaned datasets.
   - Tableau – Tableau workbook files (.twb/.twbx).
   - Web_Integration – Flask app and templates to display dashboards.
7. **Functional and Performance Testing** – Testing results, JMeter reports.
8. **Doc and Demo** – Final documentation and demo recording/videos.

> Ensure that each member contributes as per assigned responsibilities in your team.
